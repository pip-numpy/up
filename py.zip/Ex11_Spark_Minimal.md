# Ex11 – Spark / PySpark (Minimal)

**Spark** = an in-memory distributed processing engine. It is much faster than MapReduce for repeated work. A **DataFrame** is a distributed table split into partitions across the cluster. Run a program with `spark-submit app.py`, or work interactively in `pyspark`.

## 1. Full template (covers both batches)
```python
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum, avg, min, max, count, countDistinct, \
                                  when, to_date, year, month, desc

# 1. Set up Spark
spark = SparkSession.builder.appName("SalesAnalysis").master("local[*]").getOrCreate()

# 2. Load the data, then show the schema and first 5 rows
orders    = spark.read.csv("orders.csv",    header=True, inferSchema=True)
products  = spark.read.csv("products.csv",  header=True, inferSchema=True)
customers = spark.read.csv("customers.csv", header=True, inferSchema=True)
orders.printSchema();  orders.show(5)

# 3. Clean the data
orders.select([count(when(col(c).isNull(), c)).alias(c) for c in orders.columns]).show()  # nulls per column
clean = (orders.dropDuplicates()
         .withColumn("order_date", to_date(col("order_date"), "yyyy-MM-dd"))
         .filter(col("quantity").isNotNull() & (col("quantity") > 0) &
                 col("unit_price").isNotNull() & (col("unit_price") > 0))
         .withColumn("order_value", col("quantity") * col("unit_price"))
         .filter(col("order_status") != "Cancelled"))

# 4. Overall statistics
clean.select(sum("order_value"), avg("order_value"), min("order_value"),
             max("order_value"), countDistinct("customer_id")).show()
clean.groupBy("region").count().show()

# 5. Region summary (same pattern for payment_method)
regional = (clean.groupBy("region")
            .agg(sum("order_value").alias("total_value"), count("order_id").alias("orders"),
                 avg("order_value").alias("avg_value"), sum("quantity").alias("total_qty"))
            .orderBy(desc("total_value")))
regional.show(1)                                  # region with the highest total value

# 6. Join with products
op = clean.join(products.drop("category"), on="product_id", how="inner")  # drop duplicate column
category = op.groupBy("category").agg(sum("order_value").alias("total_value"),
                                      sum("quantity").alias("total_qty"),
                                      countDistinct("product_id").alias("products"))
op.groupBy("product_name").agg(sum("order_value").alias("v")).orderBy(desc("v")).show(5)

# 7. Join with customers
segment = (clean.join(customers, "customer_id")
           .groupBy("customer_segment")
           .agg(sum("order_value"), countDistinct("customer_id"), avg("order_value"), sum("quantity")))

# 8. Monthly analysis
monthly = (clean.withColumn("year", year("order_date")).withColumn("month", month("order_date"))
           .groupBy("year", "month").agg(sum("order_value").alias("total_value"),
                                         count("*").alias("orders"))
           .orderBy("year", "month"))

# Spark SQL (alternative)
clean.createOrReplaceTempView("orders")
spark.sql("SELECT region, SUM(order_value) FROM orders GROUP BY region").show()

# 9. Save as Parquet
for name, df in [("regional", regional), ("category", category),
                 ("segment", segment), ("monthly", monthly)]:
    df.write.mode("overwrite").parquet(f"output/{name}_summary")
spark.stop()
```
Note: the orders file has its own `category` column, so `products.category` would duplicate it after the join. Drop one copy (as above), otherwise Spark reports an "ambiguous column" error.

## 2. Study questions – short answers
| Question | Answer |
|---|---|
| Spark DF vs Pandas DF | Spark: distributed across a cluster, lazy, and scales to TBs. Pandas: one machine, in memory, runs immediately |
| Transformation vs Action | A transformation builds a new DataFrame lazily. An action triggers the actual computation and returns or saves the result |
| Transformations (e.g.) | `filter`, `select`, `withColumn`, `groupBy`, `join` |
| Actions (e.g.) | `show`, `count`, `collect`, `write` |
| Why lazy evaluation | Spark sees the whole plan first, then optimizes it (Catalyst: pushes filters down, prunes columns) and avoids unneeded work |
| Parquet vs CSV | Columnar, compressed and stores its schema, so Spark reads only the needed columns and skips data. That means less I/O |
| Duplicate orders problem | Inflated revenue, counts and averages, which lead to wrong decisions. Fix with `dropDuplicates()` |
| Scale to terabytes | Run on a cluster (YARN), store data in HDFS/S3 as Parquet, partition the data, cache reused DataFrames, and use broadcast joins for small tables |
