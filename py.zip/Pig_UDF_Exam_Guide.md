# Apache Pig – User Defined Functions (UDFs): Exam Guide

A **UDF** is a function you write yourself when Pig's built-in functions are not enough. The exam almost always asks for an **Eval UDF** (takes a value, returns a value) or a **Filter UDF** (returns true/false). This guide gives 12 ready-to-use UDFs with the full Java code and how to call each one.

## The fixed pattern (memorise this)
Every Eval UDF looks like this. Only the logic inside `exec()` changes.
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class MyFunc extends EvalFunc<String> {        // <String> = return type
    @Override
    public String exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null)
            return null;                               // always null-check first
        // read the argument(s)
        String val = input.get(0).toString();
        // ... logic ...
        return val;                                    // return the result
    }
}
```
- `EvalFunc<T>` – T is what the function returns: `String`, `Integer`, `Double`, `Boolean`.
- `input.get(0)` is the first argument, `input.get(1)` the second, and so on.
- `input.size()` is how many arguments were passed.

Build and use (same for every UDF):
```bash
javac -cp "$PIG_HOME/pig-0.18.0-core-h3.jar:$(hadoop classpath)" MyFunc.java
jar cf myudf.jar MyFunc.class
```
```pig
REGISTER 'myudf.jar';
B = FOREACH A GENERATE MyFunc(field) AS newfield;
```

---

## UDF 1 – Convert a string to UPPERCASE
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class ToUpper extends EvalFunc<String> {
    @Override
    public String exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return null;
        return input.get(0).toString().toUpperCase();
    }
}
```
Call: `B = FOREACH emp GENERATE ToUpper(name) AS name_upper;`
Lowercase is identical with `.toLowerCase()`.

## UDF 2 – Classify a NUMBER into a category (income / amount / marks)
The single most common exam UDF.
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class IncomeClassification extends EvalFunc<String> {
    @Override
    public String exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return "Unknown";
        double income = Double.parseDouble(input.get(0).toString());
        if (income >= 60000)      return "High Income";
        else if (income >= 40000) return "Medium Income";
        else                      return "Low Income";
    }
}
```
Call: `B = FOREACH emp GENERATE EmployeeNumber, IncomeClassification(MonthlyIncome) AS category;`

## UDF 3 – Classify a YEAR into an era (Netflix release_year)
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class ReleaseYearClassification extends EvalFunc<String> {
    @Override
    public String exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return "Unknown";
        int year = Integer.parseInt(input.get(0).toString());
        if (year >= 2020)      return "Recent";
        else if (year >= 2015) return "Modern";
        else if (year >= 2010) return "Older";
        else                   return "Classic";
    }
}
```
Call: `B = FOREACH movies GENERATE title, ReleaseYearClassification(release_year) AS era;`

## UDF 4 – Filter UDF: keep only "good" rows (returns Boolean)
A Filter UDF extends `FilterFunc` and returns `true`/`false`. Used directly inside FILTER.
```java
import java.io.IOException;
import org.apache.pig.FilterFunc;
import org.apache.pig.data.Tuple;

public class IsHighValue extends FilterFunc {
    @Override
    public Boolean exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return false;
        double amount = Double.parseDouble(input.get(0).toString());
        return amount >= 10000;        // true = keep the row
    }
}
```
Call: `B = FILTER txn BY IsHighValue(TotalAmount);`

## UDF 5 – Compute a NEW NUMBER (tax, discount, annual salary)
Returns a Double instead of a String.
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class AnnualSalary extends EvalFunc<Double> {
    @Override
    public Double exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return null;
        double monthly = Double.parseDouble(input.get(0).toString());
        return monthly * 12;
    }
}
```
Call: `B = FOREACH emp GENERATE EmployeeNumber, AnnualSalary(MonthlyIncome) AS annual;`

## UDF 6 – TWO arguments: total price = quantity x unit price
Shows how to read more than one field.
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class TotalPrice extends EvalFunc<Double> {
    @Override
    public Double exec(Tuple input) throws IOException {
        if (input == null || input.size() < 2 || input.get(0) == null || input.get(1) == null)
            return null;
        int qty      = Integer.parseInt(input.get(0).toString());
        double price = Double.parseDouble(input.get(1).toString());
        return qty * price;
    }
}
```
Call: `B = FOREACH orders GENERATE order_id, TotalPrice(quantity, unit_price) AS total;`

## UDF 7 – Trim / clean a string (remove extra spaces)
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class Trim extends EvalFunc<String> {
    @Override
    public String exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return null;
        return input.get(0).toString().trim();
    }
}
```
Call: `B = FOREACH emp GENERATE Trim(name) AS name_clean;`

## UDF 8 – Age group from age
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class AgeGroup extends EvalFunc<String> {
    @Override
    public String exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return "Unknown";
        int age = Integer.parseInt(input.get(0).toString());
        if (age < 25)      return "Young";
        else if (age <= 40) return "Middle";
        else               return "Senior";
    }
}
```
Call: `B = FOREACH emp GENERATE EmployeeNumber, AgeGroup(Age) AS age_group;`

## UDF 9 – Yes/No or flag to a readable label
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class AttritionLabel extends EvalFunc<String> {
    @Override
    public String exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return "Unknown";
        String v = input.get(0).toString();
        if (v.equalsIgnoreCase("Yes")) return "Left the Company";
        else                           return "Still Working";
    }
}
```
Call: `B = FOREACH emp GENERATE EmployeeNumber, AttritionLabel(Attrition) AS status;`

## UDF 10 – String length
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class StrLength extends EvalFunc<Integer> {
    @Override
    public Integer exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return null;
        return input.get(0).toString().length();
    }
}
```
Call: `B = FOREACH movies GENERATE title, StrLength(title) AS title_len;`

## UDF 11 – Round a number to 2 decimals
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class Round2 extends EvalFunc<Double> {
    @Override
    public Double exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return null;
        double x = Double.parseDouble(input.get(0).toString());
        return Math.round(x * 100.0) / 100.0;
    }
}
```
Call: `B = FOREACH t GENERATE Round2(avg_value) AS rounded;`

## UDF 12 – Concatenate two fields (full name, label)
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class FullName extends EvalFunc<String> {
    @Override
    public String exec(Tuple input) throws IOException {
        if (input == null || input.size() < 2) return null;
        String first = input.get(0) == null ? "" : input.get(0).toString();
        String last  = input.get(1) == null ? "" : input.get(1).toString();
        return (first + " " + last).trim();
    }
}
```
Call: `B = FOREACH cust GENERATE FullName(first_name, last_name) AS name;`

---

## Quick comparison
| # | UDF | Extends | Returns | Typical call |
|---|---|---|---|---|
| 1 | ToUpper | EvalFunc<String> | String | `ToUpper(name)` |
| 2 | IncomeClassification | EvalFunc<String> | String | `IncomeClassification(income)` |
| 3 | ReleaseYearClassification | EvalFunc<String> | String | `ReleaseYearClassification(year)` |
| 4 | IsHighValue | FilterFunc | Boolean | `FILTER t BY IsHighValue(amt)` |
| 5 | AnnualSalary | EvalFunc<Double> | Double | `AnnualSalary(monthly)` |
| 6 | TotalPrice | EvalFunc<Double> | Double | `TotalPrice(qty, price)` |
| 7 | Trim | EvalFunc<String> | String | `Trim(name)` |
| 8 | AgeGroup | EvalFunc<String> | String | `AgeGroup(age)` |
| 9 | AttritionLabel | EvalFunc<String> | String | `AttritionLabel(flag)` |
| 10 | StrLength | EvalFunc<Integer> | Integer | `StrLength(title)` |
| 11 | Round2 | EvalFunc<Double> | Double | `Round2(x)` |
| 12 | FullName | EvalFunc<String> | String | `FullName(fn, ln)` |

## Exam tips
- The exam usually gives the category table (like income or year) and asks you to "write and apply a UDF". Copy the UDF 2 or UDF 3 skeleton and change the numbers.
- Always start `exec()` with the null-check line. It prevents the whole job from crashing on a bad row.
- `Eval` returns a value; `Filter` returns true/false and is used inside `FILTER ... BY`.
- Steps to apply: write the class → `javac` → `jar cf` → `REGISTER 'x.jar';` → use inside `FOREACH ... GENERATE` or `FILTER ... BY`.
- If the class has `package myudfs;` at the top, call it as `myudfs.ClassName(...)` or shorten it with `DEFINE C myudfs.ClassName();`.
