# Big Data Analytics Lab – Viva Question Bank

Covers Apache Pig, Embedding Pig in Python, Apache Hive, and Apache Spark. Each section has one-word / short-answer questions followed by MCQs with the answer marked.

================================================================
# PART 1 – APACHE PIG
================================================================

## A. One-word / short answers
| # | Question | Answer |
|---|---|---|
| 1 | Who developed Apache Pig? | Yahoo! |
| 2 | Language used by Pig | Pig Latin |
| 3 | Pig Latin is which type of language? | Dataflow (procedural) |
| 4 | Pig converts scripts into what? | MapReduce jobs |
| 5 | Interactive shell of Pig | Grunt |
| 6 | Two execution modes of Pig | Local and MapReduce |
| 7 | Command to run in local mode | `pig -x local` |
| 8 | Default execution mode | MapReduce |
| 9 | A named dataset in Pig is called | Relation (alias) |
| 10 | A single value in Pig | Atom |
| 11 | An ordered set of fields | Tuple |
| 12 | A collection of tuples | Bag |
| 13 | A set of key-value pairs | Map |
| 14 | Symbols for tuple, bag, map | ( ), { }, [ ] |
| 15 | Operator to read data | LOAD |
| 16 | Operator to save data to HDFS | STORE |
| 17 | Operator to print to screen | DUMP |
| 18 | Default load/store function | PigStorage() |
| 19 | Default delimiter of PigStorage | Tab |
| 20 | Operator to select rows | FILTER |
| 21 | Operator to select/compute columns | FOREACH … GENERATE |
| 22 | Operator to remove duplicates | DISTINCT |
| 23 | Operator to sort | ORDER |
| 24 | Operator to restrict number of rows | LIMIT |
| 25 | Operator to group one relation | GROUP |
| 26 | Operator to group two relations | COGROUP |
| 27 | Operator to combine relations by key | JOIN |
| 28 | Cartesian product operator | CROSS |
| 29 | Operator to merge relations (stack rows) | UNION |
| 30 | Operator to divide a relation | SPLIT |
| 31 | Operator for a random subset | SAMPLE |
| 32 | Turns a bag/tuple into separate rows | FLATTEN |
| 33 | Field created automatically after GROUP | group |
| 34 | How to refer to field 1 without a schema | $0 |
| 35 | When does a Pig script actually run? | At DUMP or STORE |
| 36 | Comment symbols in Pig | `--` and `/* */` |
| 37 | Statement terminator | Semicolon ; |
| 38 | Shows the schema of a relation | DESCRIBE |
| 39 | Shows the execution plan | EXPLAIN |
| 40 | Traces sample data through steps | ILLUSTRATE |
| 41 | Four aggregate functions | COUNT, SUM, AVG, MIN/MAX |
| 42 | Function that counts nulls too | COUNT_STAR |
| 43 | Splits text into words | TOKENIZE |
| 44 | Loader for JSON data | JsonLoader |
| 45 | Keyword to load a UDF jar | REGISTER |
| 46 | Keyword to alias a UDF/macro | DEFINE |
| 47 | Is Pig case-sensitive for keywords? | No (but function names/aliases are) |
| 48 | A reusable block of Pig statements | Macro |
| 49 | Pig community function library | Piggy Bank |
| 50 | STORE fails if the output folder… | Already exists |

## B. MCQs
1. Pig Latin is a:
   a) Query language  b) **Dataflow language**  c) Markup language  d) OOP language
2. Pig scripts are internally converted into:
   a) SQL  b) **MapReduce jobs**  c) Shell scripts  d) Spark jobs
3. Which displays output on the screen?
   a) STORE  b) LOAD  c) **DUMP**  d) SAVE
4. Default delimiter of PigStorage():
   a) comma  b) space  c) **tab**  d) semicolon
5. Which operator is like SQL WHERE?
   a) FOREACH  b) **FILTER**  c) GROUP  d) ORDER
6. Which is like SQL SELECT (columns)?
   a) FILTER  b) **FOREACH…GENERATE**  c) JOIN  d) LIMIT
7. `{ (1,a), (2,b) }` is a:
   a) Tuple  b) **Bag**  c) Map  d) Atom
8. `[name#John]` is a:
   a) Tuple  b) Bag  c) **Map**  d) Atom
9. To get an overall COUNT of all rows you first use:
   a) GROUP BY key  b) **GROUP ALL**  c) DISTINCT  d) SAMPLE
10. Which removes duplicate tuples?
    a) FILTER  b) **DISTINCT**  c) UNION  d) SPLIT
11. Cartesian product is produced by:
    a) JOIN  b) **CROSS**  c) COGROUP  d) UNION
12. Which operator can produce several relations at once?
    a) **SPLIT**  b) GROUP  c) ORDER  d) LIMIT
13. Execution of a Pig script begins when:
    a) LOAD runs  b) FILTER runs  c) **DUMP/STORE is reached**  d) the file is saved
14. Diagnostic operator that shows schema:
    a) EXPLAIN  b) **DESCRIBE**  c) ILLUSTRATE  d) DUMP
15. To use a Java UDF you must first:
    a) COMPILE in Pig  b) **REGISTER the jar**  c) IMPORT  d) nothing
16. The default mode of Pig execution is:
    a) **MapReduce**  b) Local  c) Tez  d) Spark
17. Which is NOT a Pig data type?
    a) chararray  b) bytearray  c) **varchar**  d) tuple
18. Fields with no declared type are treated as:
    a) int  b) chararray  c) **bytearray**  d) null
19. A bad value that cannot be cast becomes:
    a) 0  b) error  c) **NULL**  d) empty string
20. The shell of Apache Pig is called:
    a) Hive  b) **Grunt**  c) Beeline  d) Spark shell

================================================================
# PART 2 – EMBEDDING PIG IN PYTHON (UDFs & Scripting)
================================================================

## A. One-word / short answers
| # | Question | Answer |
|---|---|---|
| 1 | Why embed Pig in Python? | Pig has no control flow (if/for) |
| 2 | Pig Latin lacks which constructs? | Loops and conditionals |
| 3 | Python module used to run Pig | subprocess |
| 4 | Method 1 of embedding | Generate a .pig file and run it |
| 5 | Method 2 of embedding | Pass Pig Latin directly with `pig -e` |
| 6 | Option to run inline Pig Latin | `-e` |
| 7 | Function to run a command in Python | subprocess.run() |
| 8 | Return code meaning success | 0 |
| 9 | Where Pig writes its log | stderr |
| 10 | Interpreter that runs embedded Python | Jython |
| 11 | Main Java class for embedding | org.apache.pig.scripting.Pig |
| 12 | Three steps of the Pig class | compile, bind, run |
| 13 | compile() returns | a Pig object |
| 14 | bind() returns | a BoundScript |
| 15 | runSingle() returns | a PigStats object |
| 16 | Checks if the job succeeded | stats.isSuccessful() |
| 17 | bind() with a list of maps enables | running many parameter sets |
| 18 | What a UDF returns in Eval type | a value |
| 19 | What a Filter UDF returns | true/false (Boolean) |
| 20 | Base class for an Eval UDF | EvalFunc |
| 21 | Base class for a Filter UDF | FilterFunc |
| 22 | Method you override in a UDF | exec(Tuple input) |
| 23 | Get the first argument in a UDF | input.get(0) |
| 24 | Package a .class into | a .jar file |
| 25 | Command to compile Java | javac |

## B. MCQs
1. Pig is embedded in Python mainly because Pig Latin lacks:
   a) loops/branches (**control flow**)  b) functions  c) data types  d) operators
2. Which Python module runs the pig command?
   a) os only  b) **subprocess**  c) sys  d) json
3. Method 2 passes Pig Latin using:
   a) a .pig file  b) **the -e option**  c) stdin only  d) a UDF
4. A returncode of 0 means:
   a) failure  b) **success**  c) empty  d) warning
5. The embedded Python is executed by:
   a) CPython  b) **Jython**  c) PyPy  d) Cython
6. Correct order of the Pig scripting class methods:
   a) bind, compile, run  b) **compile, bind, run**  c) run, bind, compile  d) compile, run, bind
7. bind() returns a:
   a) PigStats  b) **BoundScript**  c) Pig object  d) Tuple
8. An Eval UDF extends:
   a) FilterFunc  b) **EvalFunc**  c) LoadFunc  d) StoreFunc
9. A Filter UDF returns:
   a) String  b) Double  c) **Boolean**  d) Tuple
10. The method overridden in a UDF is:
    a) run()  b) **exec()**  c) main()  d) call()
11. `input.get(0)` returns:
    a) the row count  b) **the first argument**  c) the schema  d) null always
12. Which captures output in subprocess.run?
    a) shell=True  b) **capture_output=True**  c) check=True  d) text only
13. Before STORE you should:
    a) register the jar  b) **delete the old output folder**  c) run DUMP  d) compile
14. `stats.isSuccessful()` returns:
    a) output path  b) **True/False**  c) record count  d) duration
15. To run many datasets through one compiled script you pass bind:
    a) a single map  b) **a list of maps**  c) no arguments  d) a tuple

================================================================
# PART 3 – APACHE HIVE
================================================================

## A. One-word / short answers
| # | Question | Answer |
|---|---|---|
| 1 | Who developed Hive? | Facebook |
| 2 | Query language of Hive | HiveQL (HQL) |
| 3 | Hive converts queries into | MapReduce/Tez jobs |
| 4 | Where Hive stores table metadata | Metastore |
| 5 | Where the actual data lives | HDFS |
| 6 | Default warehouse path | /user/hive/warehouse |
| 7 | Command-line clients | Hive shell / Beeline |
| 8 | Hive is best for which processing? | Batch / OLAP |
| 9 | Two table types | Managed (internal) and External |
| 10 | Dropping a managed table deletes | the data too |
| 11 | Dropping an external table deletes | only the metadata |
| 12 | Keyword to create a table structure | CREATE TABLE (DDL) |
| 13 | Keyword to load a local file | LOAD DATA LOCAL INPATH |
| 14 | LOAD without LOCAL reads from | HDFS |
| 15 | Add OVERWRITE to | replace existing data |
| 16 | Add a column | ALTER TABLE … ADD COLUMNS |
| 17 | Rename a column | ALTER TABLE … CHANGE COLUMN |
| 18 | Rename a table | ALTER TABLE … RENAME TO |
| 19 | A saved query (virtual table) | View |
| 20 | View stores data? | No (only the query) |
| 21 | Drop a database with its tables | DROP DATABASE … CASCADE |
| 22 | Property to skip the CSV header | skip.header.line.count |
| 23 | Group rows for aggregation | GROUP BY |
| 24 | Filter groups after aggregation | HAVING |
| 25 | Classify values inline | CASE WHEN … END |
| 26 | Round to 2 decimals | ROUND(x,2) |
| 27 | Uppercase function | UPPER() |
| 28 | Count unique values | COUNT(DISTINCT col) |
| 29 | Extract year from a date | YEAR() |
| 30 | Keyword search in text | LIKE '%word%' |
| 31 | Show the execution plan | EXPLAIN |
| 32 | Dividing a table by a column value | Partitioning |
| 33 | Splitting data into fixed buckets | Bucketing |
| 34 | First step of a plan (read table) | TableScan |
| 35 | Partitioning improves | query speed (reads less data) |

## B. MCQs
1. Hive was developed by:
   a) Yahoo  b) **Facebook**  c) Google  d) Apache alone
2. HiveQL is most similar to:
   a) Java  b) **SQL**  c) Python  d) Pig Latin
3. Hive table metadata is stored in the:
   a) HDFS  b) **Metastore**  c) NameNode  d) warehouse file
4. Dropping a MANAGED table:
   a) keeps data  b) **deletes data and metadata**  c) deletes metadata only  d) nothing
5. Dropping an EXTERNAL table:
   a) deletes data  b) **deletes metadata only**  c) both  d) nothing
6. A Hive VIEW:
   a) stores data  b) **stores only the query**  c) is a backup  d) is a partition
7. To load a file from the Linux filesystem use:
   a) LOAD DATA INPATH  b) **LOAD DATA LOCAL INPATH**  c) PUT  d) IMPORT
8. Which filters groups after GROUP BY?
   a) WHERE  b) **HAVING**  c) FILTER  d) LIMIT
9. To classify a value inside a query use:
   a) IF  b) **CASE WHEN**  c) SWITCH  d) CLASSIFY
10. Which shows how a query will run?
    a) DESCRIBE  b) **EXPLAIN**  c) SHOW  d) ANALYZE
11. Count distinct customers:
    a) COUNT(*)  b) **COUNT(DISTINCT CustomerID)**  c) SUM(DISTINCT)  d) DISTINCT COUNT
12. Hive is mainly suited for:
    a) real-time  b) **batch/OLAP**  c) transactions  d) streaming
13. Partitioning a table helps by:
    a) sorting  b) **scanning less data**  c) removing nulls  d) joining faster always
14. Which converts descriptions to capitals?
    a) CAPS()  b) **UPPER()**  c) TOUPPER()  d) UCASE2()
15. The clause to remove the header row on load:
    a) IGNORE HEADER  b) **skip.header.line.count**  c) NO HEADER  d) HEADER OFF

================================================================
# PART 4 – APACHE SPARK (PySpark)
================================================================

## A. One-word / short answers
| # | Question | Answer |
|---|---|---|
| 1 | Spark processes data mainly in | memory (RAM) |
| 2 | Entry point of a Spark program | SparkSession |
| 3 | Basic distributed data structure | RDD |
| 4 | Table-like structured data in Spark | DataFrame |
| 5 | Python API for Spark | PySpark |
| 6 | Two operation types | Transformations and Actions |
| 7 | Builds a new DataFrame lazily | Transformation |
| 8 | Triggers actual computation | Action |
| 9 | Two example transformations | filter, select (groupBy, join) |
| 10 | Two example actions | show, count (collect, write) |
| 11 | Why Spark delays execution | Lazy evaluation (to optimize) |
| 12 | Spark's query optimizer | Catalyst |
| 13 | Command to submit a job | spark-submit |
| 14 | Run locally on all cores | master("local[*]") |
| 15 | Read a CSV | spark.read.csv(...) |
| 16 | Infer column types | inferSchema=True |
| 17 | Show the column types | printSchema() |
| 18 | Remove duplicate rows | dropDuplicates() |
| 19 | Add/compute a column | withColumn() |
| 20 | Filter rows | filter() / where() |
| 21 | Group for aggregation | groupBy().agg() |
| 22 | Count unique values | countDistinct() |
| 23 | Combine two DataFrames by key | join() |
| 24 | Run SQL on a DataFrame | createOrReplaceTempView + spark.sql |
| 25 | Preferred output format | Parquet |
| 26 | Why Parquet is faster than CSV | columnar + compressed |
| 27 | Overwrite existing output | mode("overwrite") |
| 28 | Keep a DataFrame in memory | cache() / persist() |
| 29 | Join a small table efficiently | broadcast join |
| 30 | Cluster resource manager | YARN |

## B. MCQs
1. Spark is faster than MapReduce mainly because it uses:
   a) disk  b) **in-memory processing**  c) SQL  d) fewer nodes
2. The entry point of a Spark application is:
   a) SparkContext only  b) **SparkSession**  c) RDD  d) DataFrame
3. A Spark DataFrame is:
   a) a single-machine table  b) **a distributed table**  c) a file  d) an RDD alias
4. Which is a transformation?
   a) show  b) count  c) **filter**  d) collect
5. Which is an action?
   a) select  b) withColumn  c) **count**  d) groupBy
6. Transformations in Spark are:
   a) eager  b) **lazy**  c) parallel only  d) SQL only
7. Lazy evaluation lets Spark:
   a) skip data  b) **optimize the whole plan**  c) use less RAM  d) avoid actions
8. Which format is columnar and compressed?
   a) CSV  b) JSON  c) **Parquet**  d) TXT
9. Command to run a PySpark program:
   a) pyspark-run  b) **spark-submit**  c) spark-run  d) python-spark
10. To remove duplicate orders use:
    a) distinct columns  b) **dropDuplicates()**  c) filter()  d) dropna()
11. Which combines two DataFrames on a key?
    a) union  b) **join**  c) groupBy  d) agg
12. `inferSchema=True` does what?
    a) skips header  b) **guesses column data types**  c) removes nulls  d) sorts data
13. Spark's optimizer is called:
    a) Tungsten  b) **Catalyst**  c) Grunt  d) YARN
14. To run SQL on a DataFrame you first create a:
    a) table file  b) **temporary view**  c) partition  d) bucket
15. Duplicate records would cause:
    a) faster jobs  b) **inflated totals/averages**  c) null errors  d) no effect
16. Pandas DataFrame vs Spark DataFrame – Spark is:
    a) single machine  b) **distributed and scalable**  c) in-memory only on one node  d) slower always
17. To write output and replace old data:
    a) mode("append")  b) **mode("overwrite")**  c) mode("ignore")  d) save()
18. `master("local[*]")` means run:
    a) on YARN  b) **locally on all CPU cores**  c) one core  d) on HDFS
19. A small lookup table is best joined using:
    a) cross join  b) **broadcast join**  c) outer join  d) self join
20. To reuse a DataFrame many times, you should:
    a) recompute it  b) **cache() it**  c) write to CSV  d) drop it
