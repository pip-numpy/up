# Ex08 – Embedding Pig Latin in Python

## 0. Why embed Pig in Python?
- Pig Latin is a **dataflow** language: load → transform → store. It has **no `if`, `for` or `while`**.
- Python supplies the **control flow** (loops, conditions, file handling, error checks, automation), while Pig does the **data processing** on Hadoop.
- The lab asks for two `subprocess` methods. The slides also cover the Jython `Pig` class (see section 5).

```
Python program ──subprocess──► pig command ──► MapReduce jobs on Hadoop ──► output in HDFS
```

## 1. Python building blocks you must know
| Code | Meaning |
|---|---|
| `import subprocess` | Run Linux commands (`pig`, `hdfs`) from Python |
| `script = f"""..."""` | Multi-line f-string holding the Pig Latin. `{var}` is replaced by the Python value |
| `with open('x.pig','w') as f: f.write(script)` | Create the `.pig` file (Method 1 only) |
| `r = subprocess.run([...], capture_output=True, text=True)` | Run a command and capture its output as text |
| `r.returncode` | `0` = success, anything else = failure |
| `r.stdout` / `r.stderr` | Normal output / log and error messages (Pig writes its log to stderr) |
| `subprocess.run(['hdfs','dfs','-rm','-r','-f',out])` | Delete the old output, because STORE fails if the folder already exists |

## 2. Prerequisite – the UDF JAR (Netflix batch)
| release_year | ReleaseCategory |
|---|---|
| ≥ 2020 | Recent |
| 2015–2019 | Modern |
| 2010–2014 | Older |
| < 2010 | Classic |

```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class ReleaseYearClassification extends EvalFunc<String> {
    @Override
    public String exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return "Unknown";
        int year = Integer.parseInt(input.get(0).toString());
        if (year >= 2020)      return "Recent";
        else if (year >= 2015) return "Modern";
        else if (year >= 2010) return "Older";
        else                   return "Classic";
    }
}
```
```bash
javac -cp "$PIG_HOME/pig-0.18.0-core-h3.jar:$(hadoop classpath)" ReleaseYearClassification.java
jar cf ReleaseYearClassification.jar ReleaseYearClassification.class
hdfs dfs -mkdir -p /user/hadoop/netflix
hdfs dfs -put -f netflix_titles.csv /user/hadoop/netflix/
```

## 3. Method 1 – Generate a `.pig` file, then run it  (`method1.py`)
```python
import subprocess, os

INPUT   = "/user/hadoop/netflix/netflix_titles.csv"
OUTPUT  = "/user/hadoop/netflix/output_method1"
JAR     = os.path.abspath("ReleaseYearClassification.jar")
PIG_FILE = "netflix_analysis.pig"

# 1. Pig Latin program stored in a multiline string
pig_script = f"""
REGISTER '{JAR}';

movies = LOAD '{INPUT}' USING PigStorage(',')
         AS (show_id:chararray, type:chararray, title:chararray, director:chararray,
             cast:chararray, country:chararray, date_added:chararray, release_year:int,
             rating:chararray, duration:chararray, listed_in:chararray, description:chararray);

only_movies = FILTER movies BY type == 'Movie';
recent      = FILTER only_movies BY release_year >= 2015;

result = FOREACH recent GENERATE show_id, title, country, release_year, rating,
                 ReleaseYearClassification(release_year) AS ReleaseCategory;

STORE result INTO '{OUTPUT}' USING PigStorage(',');
"""

# 2. Create the .pig file and write the program into it
with open(PIG_FILE, "w") as f:
    f.write(pig_script)
print("Pig script created:", PIG_FILE)

# 3. Remove the old output (STORE fails if the folder exists)
subprocess.run(["hdfs", "dfs", "-rm", "-r", "-f", OUTPUT], capture_output=True)

# 4. Execute the script and capture output + errors
result = subprocess.run(["pig", "-x", "mapreduce", PIG_FILE],
                        capture_output=True, text=True)
print("----- STDOUT -----\n", result.stdout)
print("----- STDERR (Pig log) -----\n", result.stderr[-3000:])   # last part of the log

# 5. Success / error message
if result.returncode == 0:
    print("SUCCESS: Pig script executed.")
else:
    print("ERROR: Pig script failed with code", result.returncode)

# 6. Verify that the output is stored in HDFS
check = subprocess.run(["hdfs", "dfs", "-test", "-e", OUTPUT + "/_SUCCESS"])
if check.returncode == 0:
    print("Output verified in HDFS:", OUTPUT)
    ls = subprocess.run(["hdfs", "dfs", "-ls", OUTPUT], capture_output=True, text=True)
    print(ls.stdout)
    cat = subprocess.run(f"hdfs dfs -cat {OUTPUT}/part-* | head -10",
                         shell=True, capture_output=True, text=True)
    print(cat.stdout)
else:
    print("Output NOT found in HDFS.")
```
Run it with `python3 method1.py`.

## 4. Method 2 – Run Pig Latin directly, with no file  (`method2.py`)
The only differences from Method 1: **no `open()/write()`**, and the string is passed with **`pig -e`**.
```python
import subprocess, os

INPUT  = "/user/hadoop/netflix/netflix_titles.csv"
OUTPUT = "/user/hadoop/netflix/output_method2"
JAR    = os.path.abspath("ReleaseYearClassification.jar")

pig_script = f"""
REGISTER '{JAR}';
movies = LOAD '{INPUT}' USING PigStorage(',')
         AS (show_id:chararray, type:chararray, title:chararray, director:chararray,
             cast:chararray, country:chararray, date_added:chararray, release_year:int,
             rating:chararray, duration:chararray, listed_in:chararray, description:chararray);
only_movies = FILTER movies BY type == 'Movie';
recent      = FILTER only_movies BY release_year >= 2015;
result = FOREACH recent GENERATE show_id, title, country, release_year, rating,
                 ReleaseYearClassification(release_year) AS ReleaseCategory;
STORE result INTO '{OUTPUT}' USING PigStorage(',');
"""

subprocess.run(["hdfs", "dfs", "-rm", "-r", "-f", OUTPUT], capture_output=True)

print("Executing Pig Latin directly from Python ...")
result = subprocess.run(["pig", "-x", "mapreduce", "-e", pig_script],
                        capture_output=True, text=True)
# Alternative: send the script to Pig's stdin
# result = subprocess.run(["pig", "-x", "mapreduce"], input=pig_script,
#                         capture_output=True, text=True)

print("----- STDOUT -----\n", result.stdout)
print("----- STDERR -----\n", result.stderr[-3000:])

if result.returncode == 0:
    print("SUCCESS: output stored in HDFS at", OUTPUT)
    print(subprocess.run(f"hdfs dfs -cat {OUTPUT}/part-* | head -10",
                         shell=True, capture_output=True, text=True).stdout)
else:
    print("ERROR: Pig execution failed.")
```
**Compare the two outputs** (they should be identical):
```bash
diff <(hdfs dfs -cat /user/hadoop/netflix/output_method1/part-* | sort) \
     <(hdfs dfs -cat /user/hadoop/netflix/output_method2/part-* | sort) && echo SAME
```

| | Method 1 | Method 2 |
|---|---|---|
| `.pig` file | Created | Not created |
| Command | `pig -x mapreduce file.pig` | `pig -x mapreduce -e "<script>"` |
| Advantage | Script can be reused, inspected and debugged | Simpler; no extra files |

## 5. Jython embedding with the `Pig` class (theory from slides)
Run with `pig pagerank.py` (Pig runs the Python using Jython).
```python
from org.apache.pig.scripting import Pig

P = Pig.compile("""
    A = LOAD '$input' USING PigStorage(',') AS (id:int, sal:int);
    B = FILTER A BY sal > $limit;
    STORE B INTO '$output';
""")                                                        # 1. compile once: syntax check, returns a Pig object
bound = P.bind({'input':'emp.csv', 'limit':'40000',
                'output':'out1'})                           # 2. bind: fill the $parameters, returns a BoundScript
stats = bound.runSingle()                                   # 3. run: returns a PigStats object
if stats.isSuccessful():
    print("Done")
else:
    raise Exception("failed")
```
- `bind()` with no arguments takes Python variables with the same names. `bind([dict1, dict2])` + `run()` runs several parameter sets in parallel and returns a list of PigStats.
- A BoundScript also supports `describe()`, `explain()` and `illustrate()`.
- Typical use is **iteration**, e.g. PageRank: loop in Python until the difference is below 0.01, running one Pig job per iteration.

## 6. Variant drill – IBM HR batch (only these parts change)
| Item | Change |
|---|---|
| UDF | `IncomeClassification(MonthlyIncome)`, e.g. ≥ 60000 High, ≥ 40000 Medium, else Low |
| Filters | `FILTER emp BY Attrition == 'Yes';` then `FILTER a BY MonthlyIncome > 40000;` |
| Projection | `FOREACH b GENERATE EmployeeNumber, Age, Department, JobRole, MonthlyIncome, IncomeClassification(MonthlyIncome) AS Incomecategory;` |
| Pig file | `employee_analysis.pig` |
| Note | In the real dataset MonthlyIncome is always < 20,000, so the output is **empty**. That's expected; say so in the viva |

## 7. Common errors and fixes
| Error | Fix |
|---|---|
| `Output directory ... already exists` | `hdfs dfs -rm -r -f <out>` before running |
| `Could not resolve ReleaseYearClassification` | Wrong REGISTER path or class name. Use the absolute path to the JAR |
| `package org.apache.pig does not exist` (javac) | Add the Pig core jar to `-cp` |
| `cannot access WritableComparable` | Add `$(hadoop classpath)` / hadoop-common jar to `-cp` |
| Wrong columns / shifted values | CSV text has commas inside quotes. Use `org.apache.pig.piggybank.storage.CSVExcelStorage(',')` after `REGISTER piggybank.jar` |
| Header row appears in output | It's removed automatically when an `int` field becomes NULL or the filter fails, or use `FILTER x BY show_id != 'show_id'` |
| `FileNotFoundError: 'pig'` in Python | Pig is not on PATH. Use the full path `$PIG_HOME/bin/pig` |
