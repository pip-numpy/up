# Apache Pig – One-Page Cheat Sheet

Big picture: **HDFS** stores huge files across many machines. **MapReduce** processes them, but you have to write it in Java. **Pig** lets you write a few lines of **Pig Latin**, and Pig turns them into MapReduce jobs for you.
Flow of every Pig script: **LOAD → transform (FILTER / FOREACH / GROUP / JOIN …) → DUMP (screen) or STORE (HDFS)**.
Nothing actually runs until a `DUMP` or `STORE` is reached (this is called lazy execution: Pig first builds a logical plan).

## 1. Running Pig

| Command | Meaning |
|---|---|
| `pig -x local` | Grunt shell. Runs in a single JVM on the local file system (for small tests) |
| `pig` or `pig -x mapreduce` | Grunt shell on Hadoop/HDFS (the default mode) |
| `pig script.pig` | Run a script file |
| `pig -x mapreduce -e "A = LOAD ...; DUMP A;"` | Run inline Pig Latin without a file (Ex08 Method 2) |
| `pig -c script.pig` / `-check` | Check syntax only; no job is run |
| `pig -param out=/x script.pig` | Pass a parameter. Inside the script, write `$out` |
| `exec script.pig` / `run script.pig` | From Grunt: run a script (`run` keeps its aliases in the shell) |
| `quit;` | Leave Grunt |

## 2. Data Model and Types

| Type | Written as | Example |
|---|---|---|
| Atom (simple value) | `int long float double chararray bytearray boolean` | `25`, `'CSE'` |
| Tuple = one row | `( )` | `(101,Ravi,85)` |
| Bag = collection of tuples | `{ }` | `{(101,Ravi),(102,Anu)}` |
| Map = key#value pairs | `[ ]` | `[city#CBE,age#21]` |

If you give no type, a field becomes `bytearray`. With no schema at all, refer to fields as `$0, $1, …`. A value that can't be converted becomes NULL (Pig warns but does not fail).
Keywords are case-insensitive (`LOAD` = `load`). **Aliases and function names are case-sensitive** (`AVG`, not `avg`).

## 3. Relational Operators (the core)

| Operator | Syntax | Meaning / Example |
|---|---|---|
| **LOAD** | `A = LOAD 'path' USING PigStorage(',') AS (id:int, name:chararray);` | Read a file into a relation. The default delimiter is TAB |
| **STORE** | `STORE A INTO 'out_dir' USING PigStorage(',');` | Write to HDFS. **Fails if `out_dir` already exists** |
| **DUMP** | `DUMP A;` | Print to the screen (for debugging) |
| **FOREACH…GENERATE** | `B = FOREACH A GENERATE id, name, sal*12 AS annual;` | Pick, rename or compute columns (like SQL SELECT) |
| **FILTER** | `B = FILTER A BY sal > 50000 AND dept == 'HR';` | Keep only rows that match (like WHERE). Use `==` for equality |
| **DISTINCT** | `B = DISTINCT (FOREACH A GENERATE role);` | Remove duplicate rows. Project the column first so you get unique values of just that column |
| **ORDER BY** | `B = ORDER A BY sal DESC, name ASC;` | Sort |
| **LIMIT** | `B = LIMIT A 10;` | First N rows (use after ORDER to get top-N) |
| **GROUP** | `G = GROUP A BY dept;` | Each output row is `(group, {bag of rows})`, where `group` is the key |
| **GROUP ALL** | `G = GROUP A ALL;` | Puts everything in one group; needed for a whole-dataset MAX, MIN or COUNT |
| **COGROUP** | `C = COGROUP A BY id, B BY id;` | Groups two relations at once: `(key, {A rows}, {B rows})` |
| **JOIN** | `J = JOIN A BY id, B BY id;` | Inner join. Refer to fields as `A::id`, `B::name` |
| Outer join | `J = JOIN A BY id LEFT OUTER, B BY id;` | Also `RIGHT OUTER` and `FULL OUTER` |
| **CROSS** | `X = CROSS A, B;` | Cartesian product (every row of A paired with every row of B) |
| **UNION** | `U = UNION A, B;` | Stack the rows of both relations. Duplicates are kept |
| **SPLIT** | `SPLIT A INTO hi IF sal>=60000, lo IF sal<40000, mid OTHERWISE;` | Divide one relation into several |
| **SAMPLE** | `S = SAMPLE A 0.1;` | Random 10 % of the rows |
| **FLATTEN** | `B = FOREACH A GENERATE id, FLATTEN(items);` | Turn a bag or tuple into separate rows or columns |
| **STREAM** | `B = STREAM A THROUGH 'python p.py';` | Send the rows through an external program |
| **MAPREDUCE** | `B = MAPREDUCE 'mr.jar' STORE A INTO 'in' LOAD 'out' AS (...);` | Run your own MapReduce jar |

## 4. Diagnostic Operators

| Command | Shows |
|---|---|
| `DESCRIBE A;` | The schema, e.g. `A: {id:int,name:chararray}` |
| `EXPLAIN A;` | The logical, physical and MapReduce plans |
| `ILLUSTRATE A;` | Sample rows traced through every step |

## 5. Built-in Functions (use them inside FOREACH)

| Function | Example (after `G = GROUP A BY dept;`) |
|---|---|
| `COUNT(bag)` (ignores nulls) / `COUNT_STAR` (counts nulls too) | `FOREACH G GENERATE group, COUNT(A);` |
| `SUM AVG MIN MAX` | `FOREACH G GENERATE group, AVG(A.sal);` (note the `A.sal` form) |
| `UPPER LOWER TRIM SUBSTRING(s,start,end) CONCAT(a,b) SIZE` | `SUBSTRING(date,0,7)` → `'2026-08'` |
| `TOKENIZE(s)` + `FLATTEN` | Word count |
| `TOP(n, col, bag)`, `ROUND(x)` | — |
| Conditional (bincond) | `(sal >= 60000 ? 'High' : 'Low') AS cat` |
| Cast / null | `(int)$2`, `x IS NULL`, `x IS NOT NULL` |

**Load/store functions:** `PigStorage(',')`, `TextLoader()` (whole line as one chararray), `JsonLoader('schema')`, `JsonStorage()`, `org.apache.pig.piggybank.storage.CSVExcelStorage(',', 'NO_MULTILINE', 'UNIX', 'SKIP_INPUT_HEADER')` (handles quoted commas and skips the header row).

## 6. UDF (User-Defined Function) – Java

| Step | Command |
|---|---|
| 1. Write a class | `public class X extends EvalFunc<String> { public String exec(Tuple t) … }` (use `FilterFunc` for a function that returns a Boolean) |
| 2. Compile | `javac -cp "$PIG_HOME/pig-*-core-h3.jar:$(hadoop classpath)" X.java` |
| 3. Package | `jar cf myudf.jar X.class` |
| 4. Register | `REGISTER 'myudf.jar';` |
| 5. Alias (optional) | `DEFINE Classify X();` |
| 6. Use | `B = FOREACH A GENERATE id, X(sal) AS category;` |

## 7. Embedding Pig in Python (Ex08)

| Way | Key lines |
|---|---|
| Method 1 – generate a .pig file | `open('f.pig','w').write(script)` → `subprocess.run(['pig','-x','mapreduce','f.pig'], capture_output=True, text=True)` |
| Method 2 – direct, no file | `subprocess.run(['pig','-x','mapreduce','-e', script], capture_output=True, text=True)` |
| Success check | `result.returncode == 0`, then `result.stdout` / `result.stderr` |
| Jython API (theory) | `from org.apache.pig.scripting import Pig` → `P = Pig.compile(s)` → `b = P.bind({'in':..})` → `stats = b.runSingle()` → `stats.isSuccessful()`; run it with `pig script.py` |

## 8. HDFS Commands Used in the Labs

| Command | Meaning |
|---|---|
| `hdfs dfs -mkdir -p /user/hadoop/in` | Make a directory |
| `hdfs dfs -put -f file.csv /user/hadoop/in/` | Upload from local to HDFS (`-f` overwrites) |
| `hdfs dfs -ls /path` | List |
| `hdfs dfs -cat /out/part-* \| head` | View output (`part-m-*` = map output, `part-r-*` = reduce output) |
| `hdfs dfs -rm -r -f /out` | Delete the old output **before STORE** |
| `hdfs dfs -get /out/part-r-00000 .` | Download |
| `hdfs dfs -test -e /out/_SUCCESS` | Exit code 0 if the job wrote output successfully |
