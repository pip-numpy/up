# Ex10 – Hive (Minimal)

**Hive** = a data warehouse on Hadoop. You write SQL-like **HiveQL**, and Hive turns it into MapReduce/Tez jobs. Table definitions (the metadata) are kept in the **Metastore**, and the data itself lives in HDFS (`/user/hive/warehouse`). Start the shell with `hive` or `beeline -u jdbc:hive2://localhost:10000`.

## 1. DDL (structure)
```sql
CREATE DATABASE IF NOT EXISTS retail_db;   SHOW DATABASES;   USE retail_db;

CREATE TABLE online_retail (
  InvoiceNo STRING, StockCode STRING, Description STRING, Quantity INT,
  InvoiceDate TIMESTAMP, UnitPrice DOUBLE, CustomerID INT, Country STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES ('skip.header.line.count'='1');      -- skip the CSV header

LOAD DATA LOCAL INPATH '/home/hadoop/OnlineRetail.csv' INTO TABLE online_retail;
-- LOCAL = copy from the Linux disk; without LOCAL = move from HDFS. Add OVERWRITE to replace the data.

SHOW TABLES;                 DESCRIBE online_retail;
ALTER TABLE online_retail ADD COLUMNS (Remarks STRING);
ALTER TABLE online_retail CHANGE COLUMN Remarks Notes STRING;        -- rename a column
ALTER TABLE online_retail SET TBLPROPERTIES ('comment'='retail data');
ALTER TABLE online_retail RENAME TO retail_txn;
CREATE VIEW v AS SELECT InvoiceNo, Quantity*UnitPrice AS TotalAmount FROM retail_txn;
DROP VIEW v;   DROP TABLE retail_txn;   DROP DATABASE retail_db CASCADE;   -- CASCADE = also drop its tables
```
**Managed vs External table:** dropping a managed table deletes its data. `CREATE EXTERNAL TABLE ... LOCATION '/hdfs/path'`: dropping it removes only the metadata.

## 2. DML / query patterns (both batches)
| Task | HiveQL |
|---|---|
| First 20 rows | `SELECT * FROM t LIMIT 20;` |
| Count rows | `SELECT COUNT(*) FROM t;` |
| Distinct count | `SELECT COUNT(DISTINCT Country) FROM t;` |
| Rows with nulls | `SELECT * FROM t WHERE CustomerID IS NULL OR Description IS NULL;` |
| Per-group totals | `SELECT Country, SUM(Quantity*UnitPrice) rev, AVG(Quantity*UnitPrice) avg_v FROM t GROUP BY Country;` |
| Highest group | `... GROUP BY StockCode ORDER BY rev DESC LIMIT 1;` |
| Above-average (subquery) | `SELECT * FROM t WHERE Quantity*UnitPrice > (SELECT AVG(Quantity*UnitPrice) FROM t);` |
| Classify (CASE) | `CASE WHEN v < 100 THEN 'Low' WHEN v <= 500 THEN 'Medium' ELSE 'High' END AS category` |
| Count per class | `SELECT category, COUNT(*) FROM (SELECT CASE ... END AS category FROM t) x GROUP BY category;` |
| Filter groups | `... GROUP BY Country HAVING SUM(Quantity) > 1000;` |

Supermarket batch: same patterns using `Branch, City, Customer_type, Gender, Product_line, Total, Quantity, Payment, Rating` (e.g. `AVG(Total) GROUP BY Gender`, `SUM(Total) GROUP BY Branch`).

## 3. Built-in functions
| Function | Example |
|---|---|
| `ROUND(x,2)` | `ROUND(AVG(Total),2)` |
| `UPPER / LOWER / TRIM / LENGTH / CONCAT / SUBSTR` | `UPPER(Customer_type)` |
| `SUM AVG MIN MAX COUNT(DISTINCT)` | `COUNT(DISTINCT CustomerID)` |
| `YEAR(d) / MONTH(d) / TO_DATE(ts)` | `YEAR(InvoiceDate)` |
| Keyword search | `WHERE UPPER(Description) LIKE '%HEART%'` or `INSTR(UPPER(Description),'HEART') > 0` |

## 4. EXPLAIN (query optimization)
```sql
EXPLAIN SELECT Country, SUM(Quantity*UnitPrice) rev FROM online_retail
WHERE Quantity > 0 GROUP BY Country ORDER BY rev DESC LIMIT 5;
```
| Look for in the output | Meaning |
|---|---|
| `TableScan` | Reads the table (full scan) |
| `Filter Operator` | The WHERE clause, applied in the map phase |
| `Group By Operator` (mode: hash, then mergepartial) | Partial aggregation in the map phase, final aggregation in the reduce phase |
| `Reduce Output Operator` | Shuffle: map → reduce |
| Sort / `Limit` | ORDER BY / LIMIT |
| `STAGE DEPENDENCIES: Stage-1, Stage-2 …` | Number of execution stages / jobs |

Optimizations: **partitioning** (`PARTITIONED BY (country STRING)`, so only the needed folders are read), **bucketing** (`CLUSTERED BY (id) INTO 4 BUCKETS`), and **predicate filtering** (a WHERE clause that runs early).
