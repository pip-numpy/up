# Ex07 – Data Analytics using Pig Latin Scripts and UDFs

## 0. Concepts in 6 lines
- **Hadoop** = HDFS (stores data split into blocks across machines) + YARN/MapReduce (processes the data in parallel).
- **Pig** = a high-level tool on top of Hadoop. You write **Pig Latin**, and Pig converts it into MapReduce jobs.
- **Relation (alias)** = a named dataset, e.g. `emp`. A relation is a **bag** of **tuples** (rows).
- **Logical plan**: Pig only checks and plans your statements. **Execution happens only at DUMP or STORE.**
- **UDF**: your own function (in Java) for logic that Pig's built-in functions can't do, e.g. classifying income.
- Modes: `pig -x local` (local files) and `pig -x mapreduce` (HDFS, the default).

## 1. Setup (terminal)
```bash
hdfs dfs -mkdir -p /user/hadoop/hr
hdfs dfs -put -f IBM_HR_Analytics_Employee_Attrition.csv /user/hadoop/hr/
pig            # opens grunt>
```

## 2. All 24 lab questions – IBM HR batch
Schema as given in the question. **Note:** the real Kaggle file has 35 columns in a different order, so list every column in the real order, or use `$n` positions.

```pig
-- Q1 + Q2: LOAD with schema
emp_raw = LOAD '/user/hadoop/hr/IBM_HR_Analytics_Employee_Attrition.csv'
          USING PigStorage(',')
          AS (EmployeeNumber:int, Age:int, Attrition:chararray, BusinessTravel:chararray,
              Department:chararray, Education:int, Gender:chararray, JobRole:chararray,
              MonthlyIncome:int, JobSatisfaction:int, YearsAtCompany:int,
              YearsInCurrentRole:int, YearsSinceLastPromotion:int, YearsWithCurrManager:int);
-- Remove the header row: the text 'EmployeeNumber' cast to int becomes NULL
emp = FILTER emp_raw BY EmployeeNumber IS NOT NULL;
DESCRIBE emp;

-- Q3: first 10 records
first10 = LIMIT emp 10;
DUMP first10;

-- Q4: select columns (projection)
sel = FOREACH emp GENERATE EmployeeNumber, Age, Gender, Department, JobRole, MonthlyIncome;

-- Q5, Q6: simple filters
high_inc = FILTER emp BY MonthlyIncome > 50000;
age35    = FILTER emp BY Age > 35;

-- Q7: string match (exact text, case-sensitive)
rnd = FILTER emp BY Department == 'Research & Development';

-- Q8
sat = FILTER emp BY JobSatisfaction >= 3;

-- Q9, Q10: sort, then top-N
sorted_inc = ORDER emp BY MonthlyIncome DESC;
top10      = LIMIT sorted_inc 10;

-- Q11: distinct values of ONE column -> project first, then DISTINCT
roles        = FOREACH emp GENERATE JobRole;
unique_roles = DISTINCT roles;

-- Q12: group
by_dept = GROUP emp BY Department;      -- (group, {emp tuples})

-- Q13, Q14, Q17: aggregates per group
dept_count  = FOREACH by_dept GENERATE group AS Department, COUNT(emp) AS emp_count;
dept_avginc = FOREACH by_dept GENERATE group AS Department, AVG(emp.MonthlyIncome) AS avg_income;
dept_avgage = FOREACH by_dept GENERATE group AS Department, AVG(emp.Age) AS avg_age;

-- Q15, Q16: overall MAX / MIN -> GROUP ALL
all_emp = GROUP emp ALL;
max_inc = FOREACH all_emp GENERATE MAX(emp.MonthlyIncome) AS max_income;
min_inc = FOREACH all_emp GENERATE MIN(emp.MonthlyIncome) AS min_income;

-- Q18: combined condition
senior_rich = FILTER emp BY YearsAtCompany > 5 AND MonthlyIncome > 40000;

-- Q19
left_emp = FILTER emp BY Attrition == 'Yes';

-- Q20: group + count
by_gender    = GROUP emp BY Gender;
gender_count = FOREACH by_gender GENERATE group AS Gender, COUNT(emp) AS cnt;
DUMP gender_count;
```
Remember: inside an aggregate, write the field as `relation.field` (e.g. `emp.MonthlyIncome`), because after GROUP the rows sit inside a bag named after the original relation.
Fact worth mentioning in the viva: real IBM HR MonthlyIncome values range from about 1,000 to 20,000, so the `> 40000` and `> 50000` filters return **no rows**. The query is still correct.

## 3. Java UDFs (Q21–Q24)

**Q21 – Uppercase UDF** (the IBM HR file has no name column, so apply it to `JobRole`. In Batch I, apply it to `CustomerName`.)
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class ToUpper extends EvalFunc<String> {
    @Override
    public String exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return null;
        return input.get(0).toString().toUpperCase();
    }
}
```
**Q22 – Classification UDF** (≥ 60,000 High · 40,000–59,999 Medium · < 40,000 Low)
```java
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class IncomeClassification extends EvalFunc<String> {
    @Override
    public String exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0 || input.get(0) == null) return "Unknown";
        double income = Double.parseDouble(input.get(0).toString());
        if (income >= 60000)      return "High Income";
        else if (income >= 40000) return "Medium Income";
        else                      return "Low Income";
    }
}
```
**Compile and package (terminal)**
```bash
javac -cp "$PIG_HOME/pig-0.18.0-core-h3.jar:$(hadoop classpath)" ToUpper.java IncomeClassification.java
jar cf hrudf.jar ToUpper.class IncomeClassification.class
```
**Q23 + Q24 – Register and apply (Pig)**
```pig
REGISTER 'hrudf.jar';
classified = FOREACH emp GENERATE EmployeeNumber, ToUpper(JobRole) AS JobRole,
                     MonthlyIncome, IncomeClassification(MonthlyIncome) AS IncomeCategory;
DUMP classified;
```
- `EvalFunc<String>` means the function returns a String. Pig calls `exec()` once for every row, and `input.get(0)` is the first argument you passed.
- If the class is inside a package (`package myudfs;`), call it as `myudfs.IncomeClassification(...)` or create a short name with `DEFINE IC myudfs.IncomeClassification();`.
- **Filter UDF** variant: `public class IsHigh extends FilterFunc { public Boolean exec(Tuple t) ... }`, then use it as `FILTER emp BY IsHigh(MonthlyIncome);`.
- To classify without a UDF, use a bincond: `(MonthlyIncome >= 60000 ? 'High' : (MonthlyIncome >= 40000 ? 'Medium' : 'Low'))`.

## 4. Batch I variant – E-Commerce (same template)
`AS (TransactionID:chararray, CustomerName:chararray, Age:int, ProductName:chararray, TotalAmount:double, PaymentMethod:chararray)`

| Question | Pig statement |
|---|---|
| Amount > 10,000 | `FILTER txn BY TotalAmount > 10000;` |
| Age > 40 | `FILTER txn BY Age > 40;` |
| Product = Laptop | `FILTER txn BY ProductName == 'Laptop';` |
| Top 10 by amount | `s = ORDER txn BY TotalAmount DESC; t = LIMIT s 10;` |
| Distinct products | `p = FOREACH txn GENERATE ProductName; d = DISTINCT p;` |
| Count / avg per payment | `g = GROUP txn BY PaymentMethod; FOREACH g GENERATE group, COUNT(txn), AVG(txn.TotalAmount);` |
| Avg age per payment | `FOREACH g GENERATE group, AVG(txn.Age);` |
| Max / min amount | `a = GROUP txn ALL; FOREACH a GENERATE MAX(txn.TotalAmount), MIN(txn.TotalAmount);` |
| Age > 30 and Amount > 5000 | `FILTER txn BY Age > 30 AND TotalAmount > 5000;` |
| Credit card | `FILTER txn BY PaymentMethod == 'Credit Card';` |
| Total per payment | `FOREACH g GENERATE group, SUM(txn.TotalAmount);` |
| UDF logic | `if (amt >= 10000) "High Value"; else if (amt >= 5000) "Medium Value"; else "Low Value";` |

**Q25 – Complete script (save as `txn.pig`, run with `pig txn.pig`)**
```pig
REGISTER 'txnudf.jar';
txn = LOAD '/user/hadoop/ecom/ECommerce_Transactions.csv' USING PigStorage(',')
      AS (TransactionID:chararray, CustomerName:chararray, Age:int,
          ProductName:chararray, TotalAmount:double, PaymentMethod:chararray);
big = FILTER txn BY TotalAmount > 5000;
res = FOREACH big GENERATE TransactionID, CustomerName, ProductName, TotalAmount,
                           TransactionClassification(TotalAmount) AS TransactionCategory;
STORE res INTO '/user/hadoop/ecom/output' USING PigStorage(',');
```
Before running it again, delete the old output with `hdfs dfs -rm -r -f /user/hadoop/ecom/output`. Check the result with `hdfs dfs -cat /user/hadoop/ecom/output/part-*`.

## 5. Viva – short answers
| Question | Answer |
|---|---|
| Apache Pig / Pig Latin | A Yahoo-built platform for analysing big data. Pig Latin is its dataflow scripting language, which compiles to MapReduce |
| Role of HDFS | Stores the input and output data. LOAD reads from HDFS and STORE writes to it |
| LOAD vs STORE | LOAD reads into a relation. STORE writes a relation to storage (permanent) |
| DUMP | Prints a relation to the screen and triggers execution (debugging) |
| FILTER vs FOREACH | FILTER chooses **rows** (like WHERE). FOREACH…GENERATE chooses or computes **columns** (like SELECT) |
| GROUP | Collects rows that share a key into `(group, bag)` so aggregates can be applied |
| GROUP vs DISTINCT | GROUP keeps every row inside bags so you can aggregate. DISTINCT just removes duplicate rows |
| Aggregate functions | COUNT, COUNT_STAR, SUM, AVG, MIN, MAX |
| UDF / why needed | User-defined function for custom logic that isn't built in. It is reusable and keeps scripts short |
| UDF languages | Java (main), plus Python/Jython, JavaScript, Ruby, Groovy |
| Register / JAR role | `REGISTER 'x.jar';`. The JAR packages the compiled class, and Pig ships it to every cluster node |
| Built-in vs UDF | Built-in functions ship with Pig (no REGISTER needed). A UDF is written by the user and must be registered |
| How Pig executes | Parse → logical plan → physical plan → MapReduce jobs, triggered by DUMP/STORE |
| Pig vs MapReduce | Pig needs a few lines and no Java, and joins are easy. MapReduce needs long Java code |
| Pig vs SQL | Pig is a procedural, step-by-step dataflow that allows nested data and optional schemas. SQL is declarative and works on flat tables |
| PigStorage() | The default load/store function for delimited text (default delimiter is TAB) |
| ORDER / LIMIT | Sort rows / keep only the first N rows |
| COUNT/SUM/AVG/MIN/MAX | Number of rows / total / mean / smallest / largest |
| Alias | The name of a relation (`emp`, `by_dept`) |
| GENERATE | Defines the output fields of FOREACH |
| Apply UDF to a field | `FOREACH r GENERATE MyUDF(field) AS newField;` |
| Local vs MapReduce mode | Local runs in one JVM on local files. MapReduce runs on the Hadoop cluster using HDFS |
