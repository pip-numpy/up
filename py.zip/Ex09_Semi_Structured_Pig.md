# Ex09 – Semi-Structured Data Processing using Pig

## 0. Concepts
- **Structured** = fixed rows and columns (CSV, tables). **Semi-structured** = has tags or keys but a flexible, nested shape (JSON, XML, logs). **Unstructured** = free text, images.
- Pig handles nesting naturally: JSON object → **tuple `( )`**, JSON array → **bag `{ }`**, key/value → **map `[ ]`**.
- `JsonLoader` reads **one complete JSON object per line** (JSON Lines / `.jsonl`). A pretty-printed file with a wrapper `{"logs":[ ... ]}` must be converted first.

## 1. Prepare the data (terminal)
```bash
# Convert the wrapper JSON to JSON Lines (one object per line)
python3 -c "import json; d=json.load(open('webserver_log_10000.json')); [print(json.dumps(x)) for x in d['logs']]" > weblog.jsonl
head -2 weblog.jsonl
hdfs dfs -mkdir -p /user/hadoop/weblog
hdfs dfs -put -f weblog.jsonl /user/hadoop/weblog/
hdfs dfs -rm -r -f /user/hadoop/weblog/output      # STORE needs a fresh output folder
```
Each line looks like this:
`{"timestamp":"2026-09-01 00:03:13","ip":"192.168.1.149","user":"U149","method":"GET","url":"/cart","status":200,"size":4194,"time_ms":120}`

## 2. Variant A – Web server log (`weblog.pig`)
```pig
-- a) Load and display
logs = LOAD '/user/hadoop/weblog/weblog.jsonl'
       USING JsonLoader('timestamp:chararray, ip:chararray, user:chararray, method:chararray,
                         url:chararray, status:int, size:long, time_ms:int');
sample10 = LIMIT logs 10;
DUMP sample10;

-- b) Extract the required fields
req = FOREACH logs GENERATE ip, user, method, url, status, size, time_ms;

-- c) Failed requests (status >= 400)
failed = FILTER req BY status >= 400;
DUMP failed;

-- d) Requests per status code
g_status     = GROUP req BY status;
status_count = FOREACH g_status GENERATE group AS status, COUNT(req) AS requests;

-- e) Requests per user
g_user     = GROUP req BY user;
user_count = FOREACH g_user GENERATE group AS user, COUNT(req) AS requests;

-- f) Average response time per URL
g_url        = GROUP req BY url;
url_avg_time = FOREACH g_url GENERATE group AS url, AVG(req.time_ms) AS avg_time_ms;

-- g) URL with the maximum number of requests
url_count = FOREACH g_url GENERATE group AS url, COUNT(req) AS requests;
url_sorted = ORDER url_count BY requests DESC;
top_url    = LIMIT url_sorted 1;

-- h) Top 5 slowest requests
slow_sorted = ORDER req BY time_ms DESC;
top5_slow   = LIMIT slow_sorted 5;

-- i) Total response size per user
user_size = FOREACH g_user GENERATE group AS user, SUM(req.size) AS total_bytes;

-- j) Store results in HDFS
STORE failed       INTO '/user/hadoop/weblog/output/failed'       USING PigStorage(',');
STORE status_count INTO '/user/hadoop/weblog/output/status_count' USING PigStorage(',');
STORE user_count   INTO '/user/hadoop/weblog/output/user_count'   USING PigStorage(',');
STORE url_avg_time INTO '/user/hadoop/weblog/output/url_avg_time' USING PigStorage(',');
STORE top_url      INTO '/user/hadoop/weblog/output/top_url'      USING PigStorage(',');
STORE top5_slow    INTO '/user/hadoop/weblog/output/top5_slow'    USING PigStorage(',');
STORE user_size    INTO '/user/hadoop/weblog/output/user_size'    USING PigStorage(',');
```
Run with `pig weblog.pig`, then view the results with `hdfs dfs -cat /user/hadoop/weblog/output/status_count/part-*`.

**If the log is plain text instead of JSON** (Apache-style lines), load each whole line and parse it with a regex:
```pig
raw = LOAD 'webserver.log' USING TextLoader() AS (line:chararray);
parsed = FOREACH raw GENERATE FLATTEN(REGEX_EXTRACT_ALL(line,
         '^(\\S+) \\S+ (\\S+) \\[.*\\] "(\\S+) (\\S+) \\S+" (\\d+) (\\d+) (\\d+)$'))
         AS (ip:chararray, user:chararray, method:chararray, url:chararray,
             status:int, size:long, time_ms:int);
```

## 3. Variant B – E-commerce nested JSON (customers + orders)
Key new ideas: **nested schema**, **dot projection**, **FLATTEN**, **SPLIT**, **JOIN `::`**, **UNION**, **GROUP ALL**.
```pig
-- a) Load (nested tuple = ( ), array = { })
cust = LOAD '/user/hadoop/ecom/customers.jsonl' USING JsonLoader(
       'customer_id:chararray, name:chararray, city:chararray, state:chararray, membership:chararray');

ord_raw = LOAD '/user/hadoop/ecom/orders.jsonl' USING JsonLoader(
  'order_id:chararray, order_date:chararray,
   customer:(customer_id:chararray, name:chararray, membership:chararray),
   items:{i:(product_id:chararray, product:chararray, category:chararray,
             price:double, quantity:int, item_total:double)},
   payment:(method:chararray, status:chararray),
   order_status:chararray,
   pricing:(subtotal:double, discount:double, total_amount:double)');

-- b) Extract: dot notation for tuples, FLATTEN for bags (one row per item)
orders = FOREACH ord_raw GENERATE order_id, order_date,
           customer.customer_id AS customer_id, payment.method AS pay_method,
           order_status, pricing.total_amount AS total;
items  = FOREACH ord_raw GENERATE order_id, FLATTEN(items) AS
           (product_id, product, category, price, quantity, item_total);

-- c) Orders > 50,000
high = FILTER orders BY total > 50000;

-- d, e) Revenue per product, top 5
gp       = GROUP items BY product;
prod_rev = FOREACH gp GENERATE group AS product, SUM(items.item_total) AS revenue;
prod_srt = ORDER prod_rev BY revenue DESC;
top5_prod = LIMIT prod_srt 5;

-- f) SPLIT by status (OTHERWISE catches Shipped/Processing etc.)
SPLIT orders INTO delivered IF order_status == 'Delivered',
                  cancelled IF order_status == 'Cancelled',
                  pending   IF order_status == 'Pending',
                  other     OTHERWISE;

-- g) Count + value per category (GROUP ALL on each split, then UNION)
dg = GROUP delivered ALL; d_stat = FOREACH dg GENERATE 'Delivered', COUNT(delivered), SUM(delivered.total);
cg = GROUP cancelled ALL; c_stat = FOREACH cg GENERATE 'Cancelled', COUNT(cancelled), SUM(cancelled.total);
pg = GROUP pending   ALL; p_stat = FOREACH pg GENERATE 'Pending',   COUNT(pending),   SUM(pending.total);
status_summary = UNION d_stat, c_stat, p_stat;
-- Shorter alternative: g = GROUP orders BY order_status; FOREACH g GENERATE group, COUNT(orders), SUM(orders.total);

-- h) JOIN on customer_id (fields from each side become relation::field)
j      = JOIN cust BY customer_id, orders BY customer_id;
joined = FOREACH j GENERATE cust::customer_id AS cid, cust::name AS name,
                            cust::membership AS membership, orders::order_id AS order_id,
                            orders::total AS total;

-- i) Premium customers' orders
premium = FILTER joined BY membership == 'Premium';

-- j) Revenue per membership
gm      = GROUP joined BY membership;
mem_rev = FOREACH gm GENERATE group AS membership, SUM(joined.total) AS revenue;

-- k) Two monthly files + UNION (both must have the same schema)
aug = LOAD '/user/hadoop/ecom/orders_aug.jsonl' USING JsonLoader('order_id:chararray, total:double');
sep = LOAD '/user/hadoop/ecom/orders_sep.jsonl' USING JsonLoader('order_id:chararray, total:double');
both = UNION aug, sep;
-- (With only one file, you can create the months instead: FILTER orders BY SUBSTRING(order_date,0,7) == '2026-08')

-- l) Total orders + revenue across both months
ga = GROUP both ALL;
months_total = FOREACH ga GENERATE COUNT(both) AS orders, SUM(both.total) AS revenue;

-- m, n) Highest customer, top 5 customers
gc        = GROUP joined BY (cid, name);
cust_tot  = FOREACH gc GENERATE FLATTEN(group) AS (cid, name), SUM(joined.total) AS spent;
cust_srt  = ORDER cust_tot BY spent DESC;
top1_cust = LIMIT cust_srt 1;
top5_cust = LIMIT cust_srt 5;

-- o) Store
STORE top5_prod      INTO '/user/hadoop/ecom/output/top5_products' USING PigStorage(',');
STORE status_summary INTO '/user/hadoop/ecom/output/status_summary' USING PigStorage(',');
STORE mem_rev        INTO '/user/hadoop/ecom/output/membership_rev' USING PigStorage(',');
STORE top5_cust      INTO '/user/hadoop/ecom/output/top5_customers' USING PigStorage(',');
```

## 4. New operators – quick explanation
| Operator | What it does | Watch out |
|---|---|---|
| `JsonLoader('schema')` | Parses one JSON object per line into a tuple | The field names must match the JSON keys |
| `a.b` (dot) | Reads field `b` from inside tuple `a` | Applied to a bag, it returns a bag of values |
| `FLATTEN(bag)` | Produces one output row per element in the bag | Rename the fields with `AS (...)` |
| `SPLIT ... IF ... OTHERWISE` | Divides one relation into several | A row can go to more than one branch if the conditions overlap |
| `JOIN A BY k, B BY k` | Inner join | Field names clash, so use `A::field` |
| `UNION A, B` | Stacks the rows | Schemas must match; duplicates are kept |
| `GROUP X ALL` | Puts everything in one group | Needed for an overall COUNT/SUM |
| `GROUP X BY (a, b)` | Multi-key group | `group` is a tuple, so use `FLATTEN(group)` or `group.a` |
| `REGEX_EXTRACT_ALL(line, re)` | Splits a raw text line into fields | Double the backslashes inside Pig strings |

## 5. Variant drill
| Question asks | Pattern |
|---|---|
| "Number of X per Y" | `GROUP r BY Y; FOREACH g GENERATE group, COUNT(r);` |
| "Total / average X per Y" | `... SUM(r.X)` / `AVG(r.X)` |
| "The Y with max …" / "Top N" | aggregate → `ORDER ... DESC` → `LIMIT 1` / `LIMIT N` |
| "Overall total" | `GROUP r ALL;` |
| "Failed / status ≥ 400" | `FILTER r BY status >= 400;` |
| "Split into categories" | `SPLIT r INTO a IF ..., b IF ..., c OTHERWISE;` |
| "Combine two datasets" (same columns) | `UNION` · (different columns, shared key) → `JOIN` |
